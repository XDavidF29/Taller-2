package com.example.app2430_7_holamundo.Logica

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.app2430_7_holamundo.R
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject


import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.InputStream
import java.io.InputStreamReader
import java.io.Writer
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import kotlin.math.roundToInt
import com.google.maps.android.SphericalUtil
import kotlinx.coroutines.DelicateCoroutinesApi


class MapsActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var lastLocation: LatLng
    private lateinit var map: GoogleMap
    private var check: Boolean = false

    // Sensor de luz
    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        val locationName = findViewById<EditText>(R.id.editTextText)

        // Verifica y solicita el permiso de ubicación
        checkLocationPermission()

        // Inicialización del SensorManager y el sensor de luz
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        handlePermissions()
        buscarUbicacion(locationName)
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync { googleMap ->
            map = googleMap
            setupLocationOverlay()
            createOverlayEvents()
            map.uiSettings.isZoomControlsEnabled = true
            map.isMyLocationEnabled = true
            buscarUbicacion(locationName)
        }
    }

    private fun readJSONArray(fileName: String): JSONArray {
        val file = File(baseContext.getExternalFilesDir(null), fileName)
        if (!file.exists()) {
            return JSONArray()
        }
        val jsonString = file.readText()
        return JSONArray(jsonString)
    }

    private fun writeJSON(location: ubicacionLive) {
        val ubicaciones = readJSONArray("ubicaciones.json")
        ubicaciones.put(location.toJSON())
        var output: Writer?
        val filename = "ubicaciones.json"
        try {
            val file = File(baseContext.getExternalFilesDir(null), filename)
            output = BufferedWriter(FileWriter(file))
            output.write(ubicaciones.toString())
            output.close()
            Toast.makeText(applicationContext, "Ubicación guardada", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun buscarUbicacion(locationName: EditText) {
        locationName.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                event?.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_ENTER) {

                val nombre = locationName.text.toString()
                val location = obtenerDireccionNombre(nombre)

                if (location != null) {
                    // Mover la cámara a la ubicación buscada
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(location.latitude, location.longitude), 15.0f))

                    // Crear el marcador en la ubicación encontrada
                    val markerOptions = MarkerOptions().position(LatLng(location.latitude, location.longitude)).title("Ubicación encontrada")
                    map.addMarker(markerOptions)

                    // Mostrar distancia
                    mostrarDistancia(lastLocation, LatLng(location.latitude, location.longitude))
                } else {
                    Toast.makeText(applicationContext, "No se encontraron resultados", Toast.LENGTH_LONG).show()
                }

                true
            } else {
                false
            }
        }
    }


    private fun obtenerDireccionNombre(text: String): LatLng? {
        val geocoder = Geocoder(this)
        val addresses = geocoder.getFromLocationName(text, 1)
        return if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            LatLng(address.latitude, address.longitude)
        } else {
            null
        }
    }



    @OptIn(DelicateCoroutinesApi::class)
    private fun drawRoute(start: LatLng, finish: LatLng) {
        val routePoints = mutableListOf<LatLng>()
        routePoints.add(start)
        routePoints.add(finish)

        // Ejecutar la llamada a la API de direcciones de Google en un hilo separado
        GlobalScope.launch(Dispatchers.IO) {
            try {
                // Construir la URL de la API de direcciones
                val url = getDirectionsUrl(start, finish)
                val directionsResult = downloadUrl(url)

                // Parsear el resultado JSON
                val result = parseDirections(JSONObject(directionsResult))

                withContext(Dispatchers.Main) {
                    if (result != null) {
                        // Dibujar la ruta en el mapa
                        val polylineOptions = PolylineOptions().apply {
                            color(Color.RED)
                            width(10f)
                            addAll(result)
                        }
                        map.addPolyline(polylineOptions)

                        // Calcular la distancia entre los dos puntos
                        val distance = SphericalUtil.computeDistanceBetween(start, finish)


                        Toast.makeText(
                            this@MapsActivity,
                            "Distancia al punto: ${distance.roundToInt()} metros",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this@MapsActivity,
                            "No se pudo obtener la ruta",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("MapsActivity", "Error al obtener la ruta", e)
            }
        }
    }

    private fun getDirectionsUrl(origin: LatLng, dest: LatLng): String {
        val originParam = "origin=${origin.latitude},${origin.longitude}"
        val destParam = "destination=${dest.latitude},${dest.longitude}"
        val sensorParam = "sensor=false"
        val apiKey = "TU_API_KEY" // Reemplaza con tu clave de API de Google
        return "https://maps.googleapis.com/maps/api/directions/json?$originParam&$destParam&$sensorParam&key=$apiKey"
    }

    private fun downloadUrl(strUrl: String): String {
        var data = ""
        var inputStream: InputStream? = null
        var urlConnection: HttpURLConnection? = null
        try {
            val url = URL(strUrl)
            urlConnection = url.openConnection() as HttpURLConnection
            urlConnection.connect()

            inputStream = urlConnection.inputStream
            val reader = BufferedReader(InputStreamReader(inputStream))

            val sb = StringBuilder()
            reader.forEachLine { sb.append(it) }

            data = sb.toString()
            reader.close()
        } catch (e: Exception) {
            Log.e("Exception", e.toString())
        } finally {
            inputStream?.close()
            urlConnection?.disconnect()
        }
        return data
    }

    private fun parseDirections(jsonObject: JSONObject): List<LatLng>? {
        val routes = jsonObject.getJSONArray("routes")
        if (routes.length() == 0) return null

        val points = mutableListOf<LatLng>()
        val legs = routes.getJSONObject(0).getJSONArray("legs")
        val steps = legs.getJSONObject(0).getJSONArray("steps")

        for (i in 0 until steps.length()) {
            val step = steps.getJSONObject(i)
            val polyline = step.getJSONObject("polyline").getString("points")
            points.addAll(decodePolyline(polyline))
        }

        return points
    }

    private fun decodePolyline(encoded: String): List<LatLng> {
        val poly = mutableListOf<LatLng>()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0

        while (index < len) {
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].code - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dlat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lat += dlat

            shift = 0
            result = 0
            do {
                b = encoded[index++].code - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dlng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lng += dlng

            val latLng = LatLng(lat / 1E5, lng / 1E5)
            poly.add(latLng)
        }

        return poly
    }



    private fun createOverlayEvents() {
        map.setOnMapLongClickListener { latLng ->
            longPressOnMap(latLng)
        }
    }



    private fun longPressOnMap(latLng: LatLng) {
        val geocoder = Geocoder(this)
        val addresses: List<Address>? = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)

        if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            val markerOptions = MarkerOptions().apply {
                position(latLng)
                title(address.getAddressLine(0))
            }
            map.addMarker(markerOptions)
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))

            // Mostrar distancia al último marcador
            mostrarDistancia(lastLocation, latLng)

            // Actualizar la última ubicación
            lastLocation = latLng
        } else {
            Toast.makeText(this, "No se encontraron direcciones para esta ubicación", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarDistancia(start: LatLng, end: LatLng) {
        val distance = SphericalUtil.computeDistanceBetween(start, end)
        Toast.makeText(this, "Distancia: ${distance.toInt()} metros", Toast.LENGTH_SHORT).show()
    }


    // Verifica el permiso de ubicación y solicítalo si es necesario
    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun handlePermissions() {
        when {
            ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED -> {
                // El permiso ya ha sido concedido
            }
            ActivityCompat.shouldShowRequestPermissionRationale(
                this, android.Manifest.permission.ACCESS_FINE_LOCATION
            ) -> {
                requestPermissions(
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                    LOCATION_PERMISSION_REQUEST_CODE
                )
            }
            else -> {
                requestPermissions(
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                    LOCATION_PERMISSION_REQUEST_CODE
                )
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permiso concedido
                } else {
                    // Permiso denegado
                    Toast.makeText(this, "Permiso de ubicación necesario para continuar.", Toast.LENGTH_SHORT).show()
                }
            }
            else -> {
                // Otros casos
            }
        }
    }

    private fun setupLocationOverlay() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val currentLatLng = LatLng(location.latitude, location.longitude)
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15.0f))

                    val markerOptions = MarkerOptions().apply {
                        position(currentLatLng)
                        title("Tu ubicación actual")
                    }
                    map.addMarker(markerOptions)

                    lastLocation = currentLatLng
                    check = true
                } else {
                    Toast.makeText(this, "No se pudo obtener la ubicación actual", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
        }
    }

    private fun calcDistance(lat1: Double, long1: Double, lat2: Double, long2: Double): Double {
        val RADIUS_OF_EARTH_KM = 6371.0 // Radio de la Tierra en kilómetros
        val latDist = Math.toRadians(lat2 - lat1)
        val lngDist = Math.toRadians(long2 - long1)

        val a = (Math.sin(latDist / 2) * Math.sin(latDist / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(lngDist / 2) * Math.sin(lngDist / 2))
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val distanceKm = RADIUS_OF_EARTH_KM * c

        return (distanceKm * 1000) // Convertir a metros
    }



    class ubicacionLive(var fecha: Date, var latitud: Double, var longitud: Double) {
        fun toJSON(): JSONObject {
            val obj = JSONObject()
            try {
                obj.put("latitud", latitud)
                obj.put("longitud", longitud)
                obj.put("fecha", fecha.time) // Guardar fecha como timestamp
            } catch (e: JSONException) {
                e.printStackTrace()
            }
            return obj
        }
    }


    override fun onSensorChanged(event: SensorEvent?) {
        // Manejo del sensor de luz
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onResume() {
        super.onResume()
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        lightSensor?.let {
            sensorManager.unregisterListener(this)
        }
    }
}