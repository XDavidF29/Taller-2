package com.example.app2430_7_holamundo.Logica

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.app2430_7_holamundo.R

class Contactos : AppCompatActivity() {

    private val PERMISSION_READ_CONTACTS = Manifest.permission.READ_CONTACTS
    private val PERMISSION_REQ_CODE = 777

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contactos)

        if (ContextCompat.checkSelfPermission(this, PERMISSION_READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            loadContacts()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(PERMISSION_READ_CONTACTS), PERMISSION_REQ_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQ_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadContacts()
            } else {
                Toast.makeText(this, "Permiso denegado para leer contactos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadContacts() {
        val contactsListView: ListView = findViewById(R.id.contacts_list)
        val contactsList = mutableListOf<Contact>()

        // Consultar los contactos
        val cursor: Cursor? = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,  // Nombre del contacto
                ContactsContract.CommonDataKinds.Phone.NUMBER         // Número de teléfono
            ),
            null, null, null
        )

        if (cursor != null && cursor.moveToFirst()) {
            var index = 1  // Para mostrar el número del contacto
            do {
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val name = cursor.getString(nameIndex)

                // Añadir el contacto a la lista
                contactsList.add(Contact(index.toString(), name))
                index++
            } while (cursor.moveToNext())
            cursor.close()
        }

        val adapter = ContactAdapter(this, contactsList)
        contactsListView.adapter = adapter
    }
}
