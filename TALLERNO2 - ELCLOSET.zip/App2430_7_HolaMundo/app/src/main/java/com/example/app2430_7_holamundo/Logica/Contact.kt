package com.example.app2430_7_holamundo.Logica

data class Contact(val number: String, val name: String)
