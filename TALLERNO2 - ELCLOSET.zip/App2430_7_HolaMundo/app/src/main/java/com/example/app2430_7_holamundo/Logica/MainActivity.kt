package com.example.app2430_7_holamundo.Logica

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.Image
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.app2430_7_holamundo.R

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imgContactos = findViewById<ImageView>(R.id.image1)
        val imgCamara = findViewById<ImageView>(R.id.image2)
        val imgMapa = findViewById<ImageView>(R.id.image3)

        imgContactos.setOnClickListener{
            val intent = Intent(this, Contactos::class.java)
            startActivity(intent)
        }

        imgCamara.setOnClickListener{
            val intent = Intent(this, Camara::class.java)
            startActivity(intent)

        }
    }

}