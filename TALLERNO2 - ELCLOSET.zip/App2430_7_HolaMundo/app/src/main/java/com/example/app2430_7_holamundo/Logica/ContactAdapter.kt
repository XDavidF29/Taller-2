package com.example.app2430_7_holamundo.Logica

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.app2430_7_holamundo.R

class ContactAdapter(context: Context, private val contacts: List<Contact>) :
    ArrayAdapter<Contact>(context, 0, contacts) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.contact_item, parent, false)

        // Obtener el contacto actual
        val contact = getItem(position)

        // Asignar el número, nombre y el icono del contacto
        val contactNumber = view.findViewById<TextView>(R.id.contact_number)
        val contactName = view.findViewById<TextView>(R.id.contact_name)
        val contactIcon = view.findViewById<ImageView>(R.id.contact_icon)

        // Llenar los datos en el layout
        contactNumber.text = contact?.number
        contactName.text = contact?.name
        contactIcon.setImageResource(R.drawable.ic_contact)  // Asegúrate de tener un icono en drawable

        return view
    }
}
